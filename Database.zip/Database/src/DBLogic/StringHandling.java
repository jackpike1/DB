package DBLogic;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class StringHandling {

    String query;
    List<String> queryList;
    StringTokenizer tokenizer;
    
    public StringHandling(String userCommand) throws Exception {
        query = userCommand;
        separateCharacters();
        tokenizeQuery();
        makeArrayList();
    }

    // Separate special characters and operators in string for commands.Parser
    private void separateCharacters() {
        query = query.replace(";", " ; ");
        query = query.replace("(", "( ");
        query = query.replace(")", " )");
        query = query.replace(",", " ,");
        query = query.replace("*", " * ");
        query = query.replace("'", " ' ");
        query = query.replace("==", " == ");
        query = query.replace(">=", " >= ");
        query = query.replace("<=", " <= ");
        query = query.replace("!=", " != ");
        query = query.replace("LIKE", " LIKE ");
        // regex to only replace single = so not to upset the operators
        query = query.replaceAll("(?<![=!><])=(?![=!><])", " = ");
        // regex to only replace single < or > when not followed by = or !
        // Adapted from https://stackoverflow.com/questions/2706745/how-to-match-the-character-not-followed-by-a-or-em-or-strong
        query = query.replace(">(?!=)", " > ");
        query = query.replace("<(?!=)", " < ");
    }

    // Tokenize query string using " " as delimiter
    private void tokenizeQuery() {
        tokenizer = new StringTokenizer(query, " ");
    }


    // Method to work out if there is an apostrophe within string
    private void makeArrayList() throws Exception {

        queryList = new ArrayList<>();

        while (tokenizer.hasMoreTokens()) {

            String temp = tokenizer.nextToken();
            // Concatenate variables within apostrophes
            if (temp.equals("'")) {
                temp = concatenateVariable();
            }
            queryList.add(temp);
        }
    }

    // Concatenate tokens from tokenizer into one string variable
    private String concatenateVariable() throws Exception {

        // Empty string case
        StringBuilder variable = new StringBuilder(tokenizer.nextToken());
        if (variable.toString().equals("'")) {
            return " ";
        }

        // Concatenate tokens until next apostrophe is found
        boolean flag = false;
        while (!flag) {
            // Error if no more tokens
            if (!tokenizer.hasMoreTokens()) {
                throw new Exception("[ERROR] Invalid query");
            }

            String temp = tokenizer.nextToken();
            // Concatenate ' on the end of word
            if (temp.equals("'")) {
                variable.append(temp);
                flag = true;
            }
            // Concatenate with space for new word
            else {
                variable.append(" ").append(temp);
            }
        }
        return "'" + variable;
    }

    // Method to return ArrayList ready for commands.Parser
    public List<String> getArrayList(){
        return queryList;
    }
}

