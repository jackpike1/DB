package DBLogic;

public class Column extends Table{

    public Column() {
    }

    // Method to rename headers to prepare for a join
    public void renameHeaders(String name) {

        // Trick to append attribute to table name and .
        for (int i = 1; i < getNumberOfColumns(); i++) {
            table.get(0).set(i, name + "." + table.get(0).get(i));
        }
    }

    // Adds column to table and fills rows with empty strings
    public void addAttribute(String attribute) {

        table.get(0).add(attribute);
        for (int i = 1; i < getNumberOfRows(); i++) {
            table.get(i).add(" ");
        }
    }
}




