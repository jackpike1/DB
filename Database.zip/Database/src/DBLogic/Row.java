package DBLogic;


import commands.Operator;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Row extends Table {

    public Row(){
    }

    // Write row to table
    public void writeRowToFile(String file, String row) {

        try {
            BufferedWriter buffWriter = new BufferedWriter(
                    new FileWriter(file, true));
            // Write row to file
            buffWriter.write(row);
            buffWriter.newLine();
            buffWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to remove rows in a table ArrayList
    public void removeRows(boolean[] rows) {

        // If rows are empty do nothing
        if (rows == null) {
        }
        else {
            // Remove rows starting at the end
            for (int i = rows.length - 1; i >= 1; i--) {
                if (!rows[i]) {
                    table.remove(i);
                }
            }
        }
    }

    // Method to update the values in the 2D ArrayList
    public void updateValue(String attribute, String value) throws Exception {

        // Find index of attribute
        int column = findAttributeIndex(attribute);

        // Returns -1 if Attribute not recognised
        if (column == -1) {
            throw new Exception("[ERROR] Attribute name not recognised");
        }

        // commands.Update column value with new value
        for (int i = 1; i < getNumberOfRows(); i++) {
            table.get(i).set(column, value);
        }
    }

    // Method to implement the conditions specified in c
    // Provides a bridge between commands.Condition class and MatchCondition
    public boolean[] implementCondition(String attribute, Operator operator, String value) throws Exception {

        // Declare an initialise boolean results array as false
        boolean[] results = new boolean[getNumberOfRows()];

        // Find index of attribute
        int column = findAttributeIndex(attribute);

        // Returns -1 if Attribute not recognised
        if (column == -1) {
            throw new Exception("[ERROR] Attribute name not recognised");
        }

        MatchConditions m = new MatchConditions();

        // Start at row 1 as we do not want to remove headers
        for (int i = 1; i < getNumberOfRows(); i++) {
            //Match cell attribute with value, according to operator
            // If condition is not true then remove row
            if ((m.matchValue(table.get(i).get(column), operator, value))) {
                results[i] = true;
            }
        }
        return results;
    }

    // If true update, if false delete
    public void makeChanges(boolean update) throws Exception {

        // Store values and read file to table
        setStoreValues();
        readTable(filepath);

        // No need to change column headers, so start at 1
        for (int i = 1; i < storeValues.size(); i++) {
            for (int j = 1; j < getNumberOfRows(); j++) {
                // If ids match for rows
                if (storeValues.get(i).get(0).equals(table.get(j).get(0))){
                    // commands.Delete if false
                    if(!update) {
                        table.remove(j);
                    }
                    // commands.Update if true
                    else {
                        table.set(j, storeValues.get(i));
                    }
                }
            }
        }
        // Write changes back to file
        writeToFile(filepath);
    }

    private void setStoreValues() {
        storeValues.addAll(table);
    }
}





