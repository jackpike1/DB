package DBLogic;

import commands.*;

import java.util.HashMap;

// This class takes two values and their operator and returns a boolean for that row
public class MatchConditions{

    public MatchConditions() {}

    public boolean matchValue(String cell, Operator operator, String value) throws Exception {

        // If values are numeric send to numeric hash map
        if (isNumeric(cell) && isNumeric(value)) {
            return runIntOperation(Integer.parseInt(cell), Integer.parseInt(value), operator);
        }
        // If one is numeric comparison should not be made
        if (isNumeric(cell) || isNumeric(value)) {
            throw new Exception("[ERROR] Invalid query");
        }
        // Else send to string hash map
        return runStringOperation(cell, value, operator);
    }

    // Return boolean result of a numeric condition
    private boolean runIntOperation(int cell, int value, Operator operator) throws Exception {

        // Hashmap types Enumerated Type commands.Operator and Boolean
        HashMap<Operator, Boolean> operatorMap = new HashMap<>();

        operatorMap.put(Operator.GREATER, isGreater(cell, value));
        operatorMap.put(Operator.SMALLER, isLess(cell,value));
        operatorMap.put(Operator.GREATERTHAN, isGreaterOrEqual(cell, value));
        operatorMap.put(Operator.LESSTHAN, isLessOrEqual(cell, value));
        operatorMap.put(Operator.EQUALS, isIntEqual(cell, value));
        operatorMap.put(Operator.NOTEQUAL, isIntNotEqual(cell, value));

        if(operatorMap.get(operator) == null) {
            throw new Exception("[ERROR] Invalid query");
        }

        return operatorMap.get(operator);
    }

    // Return boolean result of a string condition
    private boolean runStringOperation(String cell, String value, Operator operator) throws Exception {

        // Hashmap types Enumerated Type commands.Operator and Boolean
        HashMap<Operator, Boolean> operatorMap = new HashMap<>();

        operatorMap.put(Operator.EQUALS, isEquals(cell, value));
        operatorMap.put(Operator.NOTEQUAL, isNotEqual(cell, value));
        operatorMap.put(Operator.LIKE, isLike(cell, value));

        if(operatorMap.get(operator) == null) {
            throw new Exception("[ERROR] Invalid query");
        }

        return operatorMap.get(operator);
    }

    // Method to determine whether two strings are equal
    private boolean isEquals(String cell, String value) {

        return cell.equals(value);

    }

    // Method to determine whether two ints are equal
    private boolean isIntEqual(int cell, int value) {

        return cell == value;
    }


    // Method to determine whether two strings are not equal
    private boolean isNotEqual(String cell, String value) {

        return !cell.equals(value);
    }

    // Method to determine whether two ints are not equal
    private boolean isIntNotEqual(int cell, int value) {

        return cell != value;
    }

    // Method to determine whether string cell is contained in value
    private boolean isLike(String cell, String value) {

        // Remove single quotes from substring
        value = value.replace("'", "");

        return cell.contains(value);
    }

    // Method to determine whether int cell is bigger than value
    private boolean isGreater(int cell, int value) {

        return cell > value;
    }

    // Method to determine whether int cell is smaller than value
    private boolean isLess(int cell, int value) {

        return cell < value;
    }

    // Method to determine whether int cell is greater than or equal to value
    private boolean isGreaterOrEqual(int cell, int value) {

        return cell >= value;
    }

    // Method to determine whether int cell is less than or equal to value
    private boolean isLessOrEqual(int cell, int value) {

        return cell <= value;
    }

    // Regex to match a number with optional '-' and decimal
    // From https://www.regular-expressions.info/floatingpoint.html
    private boolean isNumeric(String str) {

        return str.matches("[+-]?([0-9]*[.])?[0-9]+");
    }
}
