package DBLogic;

import commands.*;

import java.io.File;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

// Getters and setters to control logic and a hashmap to go to next command
public class DBController {

    List<String> query;
    // Database logic
    static String path = "Database" + File.separator;
    Map<String, Query> queryMap = new HashMap<>();
    // Output of command
    static String output;

    public DBController()  {
    }

    // check semi-colon, Tokenize, put into hashmap
    public void runController(String command) throws Exception {

        // Prepare output
        output = "[OK]";

        if (command.equals("")) {
            throw new Exception("[ERROR] Invalid query");
        }

        // Check semi colon
        checkSemiColon(command);
        // Tokenize string
        StringHandling list = new StringHandling(command);
        query = list.getArrayList();
        // commands.Use interface to run command
        Query q = runCommand(query);

        if (q == null) {
            throw new Exception("[ERROR] Invalid query");
        }
        else {
            q.parseQuery();
            q.runQuery();
        }
    }

    // commands.Use hashmap to send off for next command
    private Query runCommand(List<String> query) {

        queryMap.put("USE", new Use(query));
        queryMap.put("CREATE", new Create(query));
        queryMap.put("DROP", new Drop(query));
        queryMap.put("INSERT", new Insert(query));
        queryMap.put("ALTER", new Alter(query));
        queryMap.put("SELECT", new Select(query));
        queryMap.put("UPDATE", new Update(query));
        queryMap.put("DELETE", new Delete(query));
        queryMap.put("JOIN", new Join(query));

        // Turns string to upper case if lower
        return queryMap.get(query.get(0).toUpperCase());
    }

    // Method to check query ends with a semi colon
    private void checkSemiColon(String command) throws Exception {

        if (!(command.substring(command.length() -1).matches(";"))) {
            throw new Exception("[ERROR] no semi colon in query");
        }
    }

    // Set Database path
    public void setPath(String updatedPath) {

        String database = "Database" + File.separator;
        path = database + updatedPath;
    }

    // Return database path
    public String getPath() {
        return path;
    }

    public void setOutput(String result) {

        output = "[OK]" + "\n" + result;
    }

    public String getOutput() {
        return output;
    }

    public void printOutput() {
        System.out.println(output);
        System.out.println("\n");
    }

}
