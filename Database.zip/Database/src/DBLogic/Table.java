package DBLogic;

import java.io.*;
import java.util.*;

public class Table {

    // Two tables needed for different commands
    ArrayList<ArrayList<String>> table;
    ArrayList<ArrayList<String>> storeValues = new ArrayList<>();
    private String output;
    String filepath;

    public Table() {
    }

    // Get table
    public ArrayList<ArrayList<String>> getTable() {

        return table;
    }

    // Set table
    public void setTable(ArrayList<ArrayList<String>> table) {

        this.table = table;
    }

    // Get number of columns in table
    public int getNumberOfColumns() {

        return table.get(0) == null ? 0 : table.get(0).size();
    }

    // Get number of rows in table
    public int getNumberOfRows() {

        return table.size();
    }

    // Method to read in file to
    public void readTable(String filepath) throws Exception {

        this.filepath = filepath;
        BufferedReader buffReader = new BufferedReader(
                new FileReader(filepath));
        String fileLine;
        String[] row;

        table = new ArrayList<>();

        // Read file rows, break into tab separated strings and fill 2D ArrayList
        int count = 0;
        while((fileLine = buffReader.readLine()) != null) {
            table.add(new ArrayList<>());
            row = fileLine.split("\t");
            for (String s : row) {
                table.get(count).add(s);
            }
            count++;
        }
        buffReader.close();
    }

    // Read in from table and write back to file
    public void writeToFile(String path) {

        try {
            BufferedWriter buffWriter = new BufferedWriter(
                    new FileWriter(path));

            // Take each line of ArrayList, and concatenate into tab separated strings
            for (ArrayList<String> s: table) {
                String newline = concatenateRow(s);
                buffWriter.write(newline);
                buffWriter.newLine();
            }
            buffWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to check whether table contains attributes
    public void checkTableAttributes(String filepath) throws Exception {

        BufferedReader buffReader = new BufferedReader(
                new FileReader(filepath));

        if (buffReader.readLine() == null) {
                throw new Exception("[ERROR] File has no attributes");
            }
    }

    // Return column of attribute
    public int findAttributeIndex(String attribute) {
        for (int i = 0; i < getNumberOfColumns(); i++) {
            if (table.get(0).get(i).equals(attribute)) {
                return i;
            }
        }
        return -1;
    }

    // Concatenate row into tab-separated string, ready for file
    public String concatenateRow(List<String> list){

        String temp = list.get(0);

        for (int i = 1; i < list.size(); i++) {
            temp = temp + "\t" + list.get(i);
        }
        return temp;
    }

    // Method to select data from table
    public String selectCommand(List<String> attributes) throws Exception {

        // if null, return entire table
        if (attributes == null) {
        }
        // Else, use attributes list to find attributes to drop from table
        else {
            List<String> drop = invertList(attributes);
            for (String s : drop) {
                dropAttribute(s);
            }
        }
        convertToString();
        return output;
    }

    // commands.Drop an attribute from table
    public void dropAttribute(String attribute) throws Exception {

        // Find attribute index and check attribute exists
        int column = findAttributeIndex(attribute);
        if (column < 0) {
            throw new Exception("[ERROR] Attribute not found in table");
        }
        // Remove column from table
        for (int i = 0; i < getNumberOfRows(); i++) {
            table.get(i).remove(column);
        }
    }

    // Concatenate rows from table into new-line separated output string
    private void convertToString() {

        // If only one row (attributes) put empty string on output
        if (getNumberOfRows() == 1) {
            output = "";
        }
        else {
            // Get first row into output
            output = concatenateRow(table.get(0));

            // Separate following rows with newline
            for (int i = 1; i < getNumberOfRows(); i++) {
                String nextLine = concatenateRow(table.get(i));
                output = output + "\n" + nextLine;
            }
        }
    }

    // Function to return the attributes in the table not in the attribute list
    private List<String> invertList(List<String> attributes) {

        List<String> drop = new ArrayList<>();

        // Iterate through first line of array
        for (String s : table.get(0)) {
            // Add attribute to drop arraylist if not in attributes
            if (!attributes.contains(s)) {
                drop.add(s);
            }
        }
        return drop;
    }

    // Method to check whether attribute exists within table
    public void checkAttributes(List<String> attributes) throws Exception {

        for (String s : attributes) {
            if (!table.get(0).contains(s)) {
                throw new Exception("[ERROR] Attribute does not exist within table");
            }
        }
    }
}
