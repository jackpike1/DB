package commands;

import java.io.File;
import java.util.List;

public class Create extends Parser implements Query {

    // Load query into commands.Parser
    public Create(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands according to BNF Grammar
    public void parseQuery() throws Exception {

        if (command.get(index).equalsIgnoreCase("DATABASE")) {
            index++;
            parseAttributeName();
            // Store database name
            name = command.get(index);
            index++;
            finishCommand();
        }

        // Looks similar to Database, but there could also be attributes
        else if (command.get(index).equalsIgnoreCase("TABLE")) {
            index++;
            parseAttributeName();
            // Store table name
            name = command.get(index);
            index++;
            parseTableList();
            finishCommand();
        }

        else {
            throw new Exception("[ERROR] No table or database specified");
        }
    }

    @Override
    public void runQuery() throws Exception {

        index = 1;
        if (command.get(index).equalsIgnoreCase("DATABASE")){
            createDataBase();
        }
        else {
            createTable();
        }
    }

    private void parseTableList() throws Exception {
        if (command.get(index).equals("(")) {
            index++;
            parseAttributeList();
            parseCommandWord(")");
            index++;
        }
    }

    // commands.Create database
    private void createDataBase() throws Exception {

        // Retrieve name, create path and directory
        File db = new File("Database" + File.separator + name);

        // Return true when creating new database

        if (db.exists()) {
            throw new Exception("[ERROR] Database already exists");
        }
        if (!db.mkdirs()) {
            throw new Exception("[ERROR] Failed to create Database");
        }
    }

    // commands.Create table
    private void createTable() throws Exception {

        // Check to see we are in a database
        if (path.equals("Database" + File.separator)) {
            throw new Exception("[ERROR] You are not inside a database yet");
        }

        // Retrieve name, create path and file
        File table = new File((path + name + filetype));

        // Check table does not exist, and create new
        if (table.exists()) {
            throw new Exception("[ERROR] Table already exists");
        }
        if (!table.createNewFile()) {
            throw new Exception("[ERROR] Failed to create table");
        }

        // Add attributes to table
        addTableAttributes();
    }

    // Write attributes to newly created table
    public void addTableAttributes() {

        // If attributes entered by user, add them as headers to new file
        if (attributes.size() > 0) {
            // id column required at index 0 in header
            row = "id" + "\t" + rows.concatenateRow(attributes);
            rows.writeRowToFile(path + name + filetype, row);
        }
    }
}

