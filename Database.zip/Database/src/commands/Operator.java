package commands;

// Enumerated type commands.Operator
public enum Operator {
    EQUALS, GREATER, SMALLER, GREATERTHAN, LESSTHAN, NOTEQUAL, LIKE;
}
