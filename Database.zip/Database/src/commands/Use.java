package commands;

import java.io.File;
import java.util.List;

public class Use extends Parser implements Query {

    // Load query into commands.Parser
    public Use(List<String> query) {
        super(query);
    }

    @Override
    // Check that the DatabaseName is valid
    public void parseQuery() throws Exception {

        parseAttributeName();
        // Store database name
        name = command.get(index);
        index++;
        finishCommand();
    }

    @Override
    // commands.Update DBLogic.DBController logic if Database exists
    public void runQuery() throws Exception {

        File db = new File( "Database" + File.separator + name);

        if (!db.exists()) {
            throw new Exception("[ERROR] Database does not exist");
        }

        else {
            logic.setPath(name + File.separator);
        }
    }
}

