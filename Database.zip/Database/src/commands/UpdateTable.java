package commands;

import DBLogic.*;
import java.util.Stack;

public class UpdateTable {

    // Stack to house attributes
    Stack<String> attributes = new Stack<>();
    // Stack to house values
    Stack<String> values = new Stack<>();

    public UpdateTable() {}

    // Add an attribute to the attributes stack
    public void addAttribute(String attribute) {
        attributes.push(attribute);
    }

    // Add a value to the values stack
    public void addValue(String value) {
        values.push(value);
    }

    // Method to change value in the table
    private void changeTableValue(Row rows) throws Exception {

        String attribute;
        String value;

        // commands.Update values inline with attributes as long as they exist on the stack
        while (attributes.size() > 0) {
            attribute = attributes.pop();
            value = values.pop();
            rows.updateValue(attribute, value);
        }
    }

    // Method to update values and then write them to file
    public void executeChanges(Row rows) throws Exception {

        changeTableValue(rows);
        rows.makeChanges(true);
    }
}
