package commands;

import java.util.ArrayList;
import java.util.List;

public class Insert extends Parser implements Query {

    // Hold values in ArrayList
    List<String> values = new ArrayList<>();

    public Insert(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands.Insert according to the BNF
    public void parseQuery() throws Exception {

        parseCommandWord("INTO");
        index++;
        parseAttributeName();
        // Store table name
        name = command.get(index);
        checkFileExists(name);
        index++;
        parseCommandWord("VALUES");
        index++;
        parseInsertValues();
        index++;
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        // Load table
        rows.checkTableAttributes(path + name + filetype);
        rows.readTable(path + name + filetype);

        // Add id to values in ArrayList
        addId();

        // Check correct number of values compared to columns
        if (rows.getNumberOfColumns() != values.size()) {
            throw new Exception("[ERROR] Incorrect number of values");
        }

        // Something I can do here? commands.Use this command elsewhere....
        // Prepare tab separated string of values and insert to table
        String row = rows.concatenateRow(values);

        rows.writeRowToFile((path + name + filetype), row);
    }

    // Find next id and add id to values ArrayList
    private void addId() throws Exception {

        // Load table
        rows.readTable(path + name + filetype);
        int id = rows.getNumberOfRows();
        // add id to the table
        values.add(0, String.format("%d", id));
    }

    // Recursive call to parse comma separated values
    private void parseValueList() throws Exception {

        parseValue();
        // Store value in values ArrayList
        values.add(command.get(index));
        index++;
        if(command.get(index).equals(",")) {
            index++;
            parseValueList();
        }
    }

    // Parse ValueList in parentheses
    private void parseInsertValues() throws Exception {

        parseCommandWord("(");
        index++;
        parseValueList();
        parseCommandWord(")");
    }
}
