package commands;

import java.util.List;

public class Update extends Parser implements Query {

    // Instance of updateTable to store attributes and values
    UpdateTable updateTable = new UpdateTable();

    public Update(List<String> query) {
        super(query);
    }

    @Override
    // Follow BNF Grammar to parse commands.Update
    public void parseQuery() throws Exception {

        parseAttributeName();
        // Store table name
        name = command.get(index);
        checkFileExists(name);
        index++;
        parseCommandWord("SET");
        index++;
        parseNameValueList();
        parseCommandWord("WHERE");
        index++;
        parseAndOrCondition(condition);
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        // Read in table
        rows.checkTableAttributes(path + name + filetype);
        rows.readTable(path + name + filetype);
        // Updates the table with conditions
        condition.getConditionResults(rows);
        // Updates the file with necessary changes
        updateTable.executeChanges(rows);
    }

    private void parseNameValueList() throws Exception {

        parseNameValuePair();
        if (command.get(index).equals(",")) {
            index++;
            parseNameValuePair();
        }
    }

    private void parseNameValuePair() throws Exception {

        parseAttributeName();
        if (command.get(index).equals("id")) {
            throw new Exception("[ERROR] You cannot update id");
        }
        // Add attribute to attributes stack in updateTable
        updateTable.addAttribute(command.get(index));
        index++;
        parseCommandWord("=");
        index++;
        parseValue();
        // Add value to values stack in updateTable
        updateTable.addValue(command.get(index));
        index++;
    }
}




