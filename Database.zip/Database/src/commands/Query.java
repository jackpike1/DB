package commands;

public interface Query {
    void parseQuery() throws Exception;
    void runQuery() throws Exception;
}





