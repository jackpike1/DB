package commands;
import DBLogic.*;

import java.util.ArrayList;
import java.util.List;

public class Join extends Parser implements Query {

    // DBLogic.Table names
    String tableOne;
    String tableTwo;
    // Value names
    String attributeOne;
    String attributeTwo;
    // A second instance of DBLogic.Table class required for join
    Column secondColumn = new Column();


    public Join(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands.Join according to BNF Grammar
    public void parseQuery() throws Exception {

        parseAttributeName();
        // Store first table name
        tableOne = command.get(index);
        index++;
        parseCommandWord("AND");
        index++;
        parseAttributeName();
        // Store second table name
        tableTwo = command.get(index);
        index++;
        parseCommandWord("ON");
        index++;
        parseAttributeName();
        // Store first attribute
        attributeOne = command.get(index);
        index++;
        parseCommandWord("AND");
        index++;
        parseAttributeName();
        // Store second attribute
        attributeTwo = command.get(index);
        index++;
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        // Read in the two respective tables and assign to local class variables
        column.checkTableAttributes(path + tableOne + filetype);
        column.checkTableAttributes(path + tableTwo + filetype);
        column.readTable(path + tableOne + filetype);
        secondColumn.readTable(path + tableTwo + filetype);

        // Get the index of the tables and minus one from second table (about to remove ids)
        int index = column.findAttributeIndex(attributeOne);
        int indexTwo = secondColumn.findAttributeIndex(attributeTwo) - 1;

        // Rename headers
        column.renameHeaders(tableOne);
        secondColumn.renameHeaders(tableTwo);

        // commands.Drop id column from second table (not required in join)
        secondColumn.dropAttribute("id");

        // Get tables
        // DBLogic.Table to add join
        ArrayList<ArrayList<String>> tableNumberOne = column.getTable();
        ArrayList<ArrayList<String>> tableNumberTwo = secondColumn.getTable();

        // commands.Create join table to hold result of join
        ArrayList<ArrayList<String>> joinTable = new ArrayList<>();
        joinTable.add(new ArrayList<>());
        joinTable.get(0).addAll(tableNumberOne.get(0));
        joinTable.get(0).addAll(tableNumberTwo.get(0));

        // Append second table attributes to first
        int count = 0;
        // Iterate through the selected index
        for (int i = 1; i < column.getNumberOfRows(); i++) {
            for (int j = 1; j < secondColumn.getNumberOfRows(); j++) {

                // If value in first table equals value in second
                if (tableNumberOne.get(i).get(index).equals(tableNumberTwo.get(j).get(indexTwo))) {
                    count++;

                    // commands.Join entire row to first table
                    joinTable.add(new ArrayList<>());
                    joinTable.get(count).addAll(tableNumberOne.get(i));
                    joinTable.get(count).addAll(tableNumberTwo.get(j));
                }
            }
        }

        // Put join table in table class
        column.setTable(joinTable);
        // Save the output on the last string
        logic.setOutput(column.selectCommand(null));
    }
}


