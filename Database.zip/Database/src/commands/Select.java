package commands;

import java.util.List;

public class Select extends Parser implements Query {

    public Select(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands.Select according to BNF Grammar
    public void parseQuery() throws Exception {

        parseWAttributeList();
        parseCommandWord("FROM");
        index++;
        parseAttributeName();
        // Store table name
        name = command.get(index);
        checkFileExists(name);
        index++;
        if (command.get(index).equalsIgnoreCase("WHERE")) {
            index++;
            parseAndOrCondition(condition);
        }
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        //Read in table to ArrayList
        rows.checkTableAttributes(path + name + filetype);
        rows.readTable(path + name + filetype);

         index = 5;

         // Updates the table if there are any conditions to update
         condition.getConditionResults(rows);

         index = 1;

        // commands.Select command returns concatenated output string of entire table when set to null
         if (command.get(index).equals("*")) {
            logic.setOutput(rows.selectCommand(null));
         }
         // commands.Select command returns concatenated output string from table with correct attributes
        else {
            rows.checkAttributes(attributes);
            logic.setOutput(rows.selectCommand(attributes));
        }
    }

    // Parse WildAttributeList as in the BNF
    private void parseWAttributeList() throws Exception {

        if (command.get(index).equals("*")) {
            index++;
        }
        else if (parseAttributeList()) {
        }
        else {
            throw new Exception("[ERROR] Invalid query");
        }
    }
}
