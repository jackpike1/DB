package commands;

import java.util.List;

public class Delete extends Parser implements Query {

    public Delete(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands according to BNF Grammar
    public void parseQuery() throws Exception {

        parseCommandWord("FROM");
        index++;
        parseAttributeName();
        name = command.get(index);
        checkFileExists(name);
        index++;
        if (command.get(index).equalsIgnoreCase("WHERE")) {
            index++;
            parseAndOrCondition(condition);
        }
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        rows.checkTableAttributes(path + name + filetype);
        rows.readTable(path + name + filetype);

        // Updates the table if there are any conditions to update
        condition.getConditionResults(rows);

        // Method goes ahead to delete rows
        rows.makeChanges(false);
    }
}
