package commands;
import DBLogic.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

// Class containing general parsing methods needed for various commands
abstract class Parser {

    List<String> command;
    List<String> attributes = new ArrayList<>();
    String filetype = ".tab";
    String name;
    String row;
    int index;
    // Controller logic required for navigating database
    DBController logic = new DBController();
    String path = logic.getPath();
    // commands.Condition class for commands with condition
    Condition condition = new Condition();
    // TESTER FOR ROWS AND ATTRIBUTES
    Column column = new Column();
    Row rows = new Row();

    // commands.Use tokenizer to save tab-separated strings in parseCommand ArrayList variable
    public Parser(List<String> query) {

        // commands.Use String Handling Class to prepare string for Parsing
        command = query;
        // Start at index at one because 0th index has been put through the hash map
        index = 1;
    }

    // Check the last character is a ; and the command finishes
    void finishCommand() throws Exception {
        if (!command.get(index).equals(";")) {
            throw new Exception("[ERROR] Invalid query");
        }
        index++;
        // Check command has finished
        if (index < command.size()) {
            throw new Exception("[ERROR] Invalid query");
        }
    }

    // Check whether current index equals to String word
    void parseCommandWord(String word) throws Exception {

        if (!command.get(index).equalsIgnoreCase(word)) {
            throw new Exception("[ERROR] Invalid query");
        }
    }

    // Check regex for alphanumeric characters... Used in CREATE
    void parseAttributeName() throws Exception {

        if (!command.get(index).matches("^[a-zA-Z0-9]+$")) {

            throw new Exception("[ERROR] Invalid query");
        }
    }

    // Parse AttributeList (column names) according to formal grammar
    boolean parseAttributeList() throws Exception {

        parseAttributeName();
        // Add attribute to attribute arraylist
        attributes.add(command.get(index));
        index++;

        // If comma, recursive call, if not return true
        if (command.get(index).equals(",")) {
            index++;
            parseAttributeList();
        }
        return true;
    }

    // adapted from https://stackoverflow.com/questions/17495418/regular-expression-greater-than-and-less-than
    void parseOperator() throws Exception {

        if(!command.get(index).matches("[<>]=?|==|LIKE|!=")){
            throw new Exception("[ERROR] Invalid query");
        }
    }

    // Parse BooleanLiteral according to formal grammar
    boolean parseBooleanLiteral() {

        return command.get(index).equals("true") || command.get(index).equals("false");
    }

    // adapted from https://stackoverflow.com/questions/12643009/regular-expression-for-floating-point-numbers
    // Parses Float and integer
    boolean parseNumber() {

        return command.get(index).matches("[+-]?([0-9]*[.])?[0-9]+");
    }

    // Parse string literal, including empty strings
    // Written using https://www.rexegg.com/regex-quickstart.html
    boolean parseStringLiteral() throws NoSuchElementException{

        return command.get(index).matches("\\s|^'[a-zA-Z0-9_,-;./:[^'\\t] ,]+'$");
    }

    // Parse value
    void parseValue() throws Exception {

        if (parseStringLiteral() || parseBooleanLiteral() || parseNumber()) {
        }
        else {
            throw new Exception("[ERROR] Invalid query");
        }
    }

    // Parse a simple condition
    private void parseCondition(Condition condition) throws Exception {

        parseAttributeName();
        // Store Attribute Name in commands.Condition class
        condition.setAttribute(command.get(index));
        index++;
        parseOperator();
        // Store operator in commands.Condition class
        condition.setOperator(command.get(index));
        index++;
        parseValue();
        // Store value in commands.Condition class
        condition.setValue(command.get(index));
        index++;
    }

    // Parse all types of conditions
    void parseAndOrCondition(Condition condition) throws Exception {

        parseBracketedCon(condition);
        if (command.get(index).equalsIgnoreCase("AND")) {
            // Add to commands.Condition conjunction stack
            condition.addConjunction("AND");
            index++;
            parseBracketedCon(condition);
        }
        else if (command.get(index).equalsIgnoreCase("OR")) {
            // Add to commands.Condition conjunction stack
            condition.addConjunction("OR");
            index++;
            parseBracketedCon(condition);
        }
        else {
            parseCondition(condition);
        }
    }

    // parseCondition with brackets
    private void parseBracketedCon(Condition condition) throws Exception {

        if (command.get(index).equals("(")) {
            index++;
            parseAndOrCondition(condition);
            parseCommandWord(")");
            index++;
        }
    }

    // Method to check whether a file exists
    void checkFileExists(String name) throws Exception {

        File check = new File(path + name + filetype);

        if (!check.exists()) {
            throw new Exception("[ERROR] Table does not exist");
        }
    }
}
