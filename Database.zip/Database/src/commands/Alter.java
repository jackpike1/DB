package commands;

import java.util.List;

public class Alter extends Parser implements Query {

    // Store name, attribute and alteration data
    String attribute;
    boolean alteration = false;

    public Alter(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands.Alter according to BNF Grammar
    public void parseQuery() throws Exception {

        parseCommandWord("TABLE");
        index++;
        parseAttributeName();
        // Store table name
        name = command.get(index);
        checkFileExists(name);
        index++;
        parseAlteration();
        index++;
        parseAttributeName();
        // Store attribute name
        attribute = command.get(index);
        index++;
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        // Open table
        column.checkTableAttributes(path + name + filetype);
        column.readTable(path + name + filetype);

        // Add attribute to table
        if (alteration) {
            column.addAttribute(attribute);
        }
        // commands.Drop attribute from table
        else {
            column.dropAttribute(attribute);
        }
        column.writeToFile(path + name + filetype);
    }

    // Parse Alteration
    private void parseAlteration() throws Exception {

        if (command.get(index).equalsIgnoreCase("ADD")) {
            // Make alteration boolean true for ADD
            alteration = true;
        }
        else if (command.get(index).equalsIgnoreCase("DROP")) {
        }
        else {
            throw new Exception("[ERROR] Invalid query");
        }
    }
}