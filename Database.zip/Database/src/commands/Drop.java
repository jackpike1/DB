package commands;

import java.io.File;
import java.util.List;

public class Drop extends Parser implements Query {

    String structure;

    public Drop(List<String> query) {
        super(query);
    }

    @Override
    // Parse commands.Drop according to BNF Grammar
    public void parseQuery() throws Exception {

        parseAttributeName();
        // Store Structure
        structure = command.get(index);
        index++;
        parseAttributeName();
        // Store table name
        name = command.get(index);
        index++;
        finishCommand();
    }

    @Override
    public void runQuery() throws Exception {

        if (structure.equalsIgnoreCase("TABLE")) {
            checkFileExists(name);
            dropTable();
        }
        else if (structure.equalsIgnoreCase("DATABASE")){
            dropDatabase();
        }
        // Technically parsing here, but it helps reduce complexity in parser
        else {
            throw new Exception("[ERROR] Invalid query");
        }
    }

    // Removes specified table from database
    private void dropTable() throws Exception {

        // Get path and delete table
        File table = new File((path + name + filetype));
        if (!table.delete()) {
            throw new Exception("[ERROR] Failed to drop this table");
        }
    }

    // Removes database
    private void dropDatabase() throws Exception {

        File database = new File("Database" + File.separator + name);

        if (!database.exists()) {
            throw new Exception("[ERROR] Database does not exist");
        }

        File[] listFiles = database.listFiles();

        // commands.Delete files within database first
        for (File file : listFiles) {
            file.delete();
        }
        // commands.Delete database
        if (!database.delete()) {
            throw new Exception("[ERROR] Failed to drop this database");
        }
        // Reset path
        logic.setPath("");
    }
}
