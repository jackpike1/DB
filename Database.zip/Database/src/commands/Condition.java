package commands;
import DBLogic.*;

import java.util.*;

public class Condition {

    Map<String, Operator> operatorMap = new HashMap<>();
    // ArrayList for holding ADD and OR conjunctions
    Stack<String> conjunctions = new Stack<>();
    // Linked lists of boolean arrays to store results
    LinkedList<boolean[]> results = new LinkedList<>();
    // Stack to store attributes
    Stack<String> attributes = new Stack<>();
    // Stack to store operators
    Stack<Operator> operators = new Stack<>();
    // Stack to store values
    Stack<String> values = new Stack<String>();
    // Final result boolean representation of rows to send to table class
    boolean[] finalResult;

    public Condition(){

        operatorMap.put("==", Operator.EQUALS);
        operatorMap.put(">", Operator.GREATER);
        operatorMap.put("<", Operator.SMALLER);
        operatorMap.put(">=", Operator.GREATERTHAN);
        operatorMap.put("<=", Operator.LESSTHAN);
        operatorMap.put("!=", Operator.NOTEQUAL);
        operatorMap.put("LIKE", Operator.LIKE);

    }

    // Method to get the results of the conditions
    public void getConditionResults(Row rows) throws Exception {

        // Do nothing if no conditions
        if (attributes.size() == 0) {
        }
        // Else, run conditions
        else {
            emptyStacks(rows);
            runConjunction();
            rows.removeRows(finalResult);
        }
    }

    // Push attribute to the attribute stack
    public void setAttribute(String attribute) {
        attributes.push(attribute);
    }

    // Add commands.Operator to operators stack
    public void setOperator(String operator) throws Exception {

        if (operatorMap.get(operator) == null) {
            throw new Exception("[ERROR] Invalid query check your operator");
        }
        operators.push(operatorMap.get(operator));
    }

    // Add Value to values stack
    public void setValue(String value) {
        values.push(value);
    }

    // Push conjunction to the stack of conjunctions
    public void addConjunction(String conjunction) {
        conjunctions.push(conjunction);
    }

    // Pops off conditions to retrieve results array
    private void fillResultsStack(Row rows) throws Exception {

        // Pop off commands.Condition variables
        String attribute = attributes.pop();
        Operator operator = operators.pop();
        String value = values.pop();

        // Retrieve boolean results from rows and push to stack
        boolean[] tempResult;
        tempResult = rows.implementCondition(attribute, operator, value);

        // Add result to linked list of results
        results.add(tempResult);
    }

    // Method to empty the condition stacks and fill results stack
    private void emptyStacks(Row rows) throws Exception {

        while (attributes.size() > 0) {
            fillResultsStack(rows);
        }
    }

    // Method to run any conjunctions on results list
    private void runConjunction() {

        String conjunction;
        boolean[] firstResult = results.pop();
        boolean[] secondResult;

        // Only continue this while there are boolean results in linked list
        while (results.size() > 0) {
            // Pop latest boolean array result into variable
            secondResult = results.pop();
            // Get the next conjunction
            conjunction = conjunctions.pop();

            // Send to respective methods
            if (conjunction.equals("AND")) {
                firstResult = runAndResults(firstResult, secondResult);
            }
            else {
                firstResult = runOrResults(firstResult, secondResult);
            }
        }
        // commands.Update final result boolean
        finalResult = firstResult;
    }

    // AND two boolean result tables together
    private boolean[] runAndResults(boolean[] firstResult, boolean[] secondResult) {

        // Declare and initialize results array to correct size
        boolean[] finalResult = new boolean[firstResult.length];

        // Iterate through two arrays
        for (int i = 0; i < firstResult.length; i++) {
            // If both arrays are true then final result is true
            if (firstResult[i]  && secondResult[i] ) {
                finalResult[i] = true;
            }
        }
        return finalResult;
    }

    // OR two boolean results tables together
    private boolean[] runOrResults(boolean[] firstResult, boolean[] secondResult) {

        // Declare and initialize results array to correct size
        boolean[] finalResult = new boolean[firstResult.length];

        for (int i = 0; i < firstResult.length; i++) {

            if (firstResult[i] || secondResult[i]) {
                finalResult[i] = true;
            }
        }
        return finalResult;
    }
}
